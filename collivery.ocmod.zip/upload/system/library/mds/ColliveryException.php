<?php

namespace Mds;

class ColliveryException extends \Exception
{

}
