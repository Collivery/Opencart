<?php

class ControllerExtensionShippingCollivery extends Controller {

    public function index() {

    }

    public function install() {

    }

    public function uninstall() {

    }

}