<?php

class collivery
{
    protected $registry;

    public function __construct($registry) {
        $this->registry = $registry;
    }

}
